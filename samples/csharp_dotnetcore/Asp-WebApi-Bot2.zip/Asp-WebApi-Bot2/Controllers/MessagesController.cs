﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Connector.Authentication;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Configuration;

namespace Asp_WebApi_Bot2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MessagesController : ControllerBase
    {
        private BotFrameworkAdapter botframeworkAdapter;

        public MessagesController(BotFrameworkAdapter adapter)
        {
            this.botframeworkAdapter = adapter;
        }

        // Bot framework protocol does a POST to api/messages with Activity object
        [HttpPost]
        public async Task<object> Post([FromBody] Activity activity)
        {
            return await botframeworkAdapter.ProcessActivityAsync(Request.Headers["Authorization"], activity, OnTurnAsync, default(CancellationToken));
        }

        protected virtual async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            if (turnContext.Activity.Type == ActivityTypes.Message)
            {
                await turnContext.SendActivityAsync(MessageFactory.Text($"Echo xxxx '{turnContext.Activity.Text}' from bot 1."));
            }
            else if (turnContext.Activity.Type == ActivityTypes.ConversationUpdate)
            {
                if (turnContext.Activity.MembersAdded.Any())
                {
                    foreach (var member in turnContext.Activity.MembersAdded)
                    {
                        if (member.Id != turnContext.Activity.Recipient.Id)
                        {
                            await turnContext.SendActivityAsync(MessageFactory.Text($"Welcome {member.Name} to ASP MVC Bot 2."), cancellationToken);
                        }
                    }
                }
            }
        }

    }
}
